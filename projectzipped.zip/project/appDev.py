from flask import Flask,render_template,request,redirect,url_for
import os
import pandas as pd
from datetime import datetime
app=Flask(__name__)

# logid=''
# logIn=''
# logOut=''
@app.route('/')
def home():
    return render_template('login.html')

@app.route('/admin_dashboard',methods=['POST','GET'])
def login():
    error=None
    if request.method=='POST': 
        try:      
            unm=request.form['userid']
            pwd=request.form['pwd']
            rel_path="/data/employees.csv"
            path=os.getcwd()+rel_path
            # if not os.path.exist(path):
            df_emp=pd.read_csv(path)

            if df_emp[df_emp['Username']==unm]['Password'].values[0]==pwd and df_emp[df_emp['Username']==unm]['Role'].values[0]=='Admin' :
                # logIn=datetime.now()
                # logid=df_emp[df_emp['Username']==unm]['EmpID'].values[0]
                return render_template('admin_dashboard.html')
            if df_emp[df_emp['Username']==unm]['Password'].values[0]==pwd and df_emp[df_emp['Username']==unm]['Role'].values[0]=='User' :
                return render_template('user_dashboard.html')
            
            error="Invalid Username and Password!"

        except:
            error="Invalid Username and Password!"
        return render_template("login.html",error=error)

@app.route('/adm_employees')
def adm_emp_but():

    rel_path="/data/employees.csv"
    path=os.getcwd()+rel_path      
    with open(path,"r") as f:
        data=f.readlines()[1:]
    rows=[]
    for line in data:
        rows.append(line.strip('\n').split(','))
    newid = int(rows[-1][0])+1
    return render_template('admin_employees.html', data=rows,new_empid=newid)

@app.route('/adm_employees',methods=['POST','GET'])
def adm_add_emp():
    if request.method=='POST':
        rel_path="/data/employees.csv"
        path=os.getcwd()+rel_path 
        with open(path,"r") as f:
            data=f.readlines()
        rows=[]
        for line in data:
            rows.append(line.strip('\n').split(','))

        for row in rows:
            if row[0]==request.form['empid']:
                df_emp=pd.read_csv(path)
                df_emp=df_emp.astype(str)
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'EmpName'] = request.form['empname']
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'EmailID'] = request.form['emailid']
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'Username'] = request.form['username']
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'Password'] = request.form['username']+request.form['empid']
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'Role'] = request.form['role']
                df_emp.loc[df_emp['EmpID'] == request.form['empid'], 'Category'] = request.form['category']
                df_emp.to_csv(path,index=False)
                return redirect('/adm_employees')

        line = request.form['empid'] + ',' + request.form['empname']+ ',' + request.form['emailid'] + ',' + request.form['username'] + ',' + request.form['username']+request.form['empid'] + ',' + request.form['role'] + ',' + request.form['category']
        
        with open(path,"a") as f:
            f.write(line)
            f.write("\n")
        return redirect('/adm_employees')

@app.route('/adm_emp_del', methods=['POST','GET'])
def adm_emp_del_but():
    if request.method=='POST':
        rel_path="/data/employees.csv"
        path=os.getcwd()+rel_path
        df_emp=pd.read_csv(path)
        df_emp=df_emp.astype(str)
        df_emp=df_emp[df_emp['EmpID'] != request.form['empid']]
        df_emp.to_csv(path,index=False)
        return redirect('/adm_employees')


@app.route('/adm_categories')
def adm_cat_but(view=[]):
    rel_path="/data/categories.csv"
    path=os.getcwd()+rel_path      
    with open(path,"r") as f:
        data=f.readlines()[1:]
    rows=[]
    for line in data:
        rows.append(line.strip('\n').split(','))
    newid = int(rows[-1][0])+1
    return render_template('admin_categories.html', catdata=rows,empdata=view,new_catid=newid)

@app.route('/adm_categories', methods=['POST','GET'])
def adm_cat_add():
    if request.method=='POST':
        rel_path="/data/categories.csv"
        path=os.getcwd()+rel_path 
        with open(path,"r") as f:
            data=f.readlines()
        rows=[]
        for line in data:
            rows.append(line.strip('\n').split(','))

        for row in rows:
            if row[0]==request.form['catid']:
                df_cat=pd.read_csv(path)
                df_cat=df_cat.astype(str)
                df_cat.loc[df_cat['ID'] == request.form['catid'], 'CATEGORY'] = request.form['catname']
                df_cat.to_csv(path,index=False)
                return redirect('/adm_categories')

        line = request.form['catid'] + ',' + request.form['catname']
        
        with open(path,"a") as f:
            f.write(line)
            f.write("\n")
        return redirect('/adm_categories')

@app.route('/adm_cat_del', methods=['POST','GET'])
def adm_cat_del():
    if request.method=='POST':
        rel_path="/data/categories.csv"
        path=os.getcwd()+rel_path
        df_cat=pd.read_csv(path)
        df_cat=df_cat.astype(str)
        df_cat=df_cat[df_cat['ID'] != request.form['catid']]
        df_cat.to_csv(path,index=False)
        return redirect('/adm_categories')

@app.route('/adm_cat_view', methods=['POST','GET'])
def adm_cat_view_emp():
    if request.method=='POST':
        rel_path="/data/employees.csv"
        path=os.getcwd()+rel_path
        df_emp=pd.read_csv(path)
        df_emp=df_emp.astype(str)
        df_emp=df_emp[df_emp['Category'] == request.form['catid']]
        df_emp=df_emp.values.tolist()
        # df_cat.to_csv(path,index=False)
        return adm_cat_but(df_emp)


@app.route('/adm_quiz')
def adm_quiz_but(qn_view=[]):
    rel_path="/data/quiz.csv"
    path=os.getcwd()+rel_path      
    with open(path,"r") as f:
        data=f.readlines()[1:]
    rows=[]
    for line in data:
        rows.append(line.strip('\n').split(','))
    if not rows:
        newid=1
    else:
        newid = int(rows[-1][0])+1


    # if new_qz_det:
    #     newid=new_qz_det[0]
    #     nqd,new_qz_det=new_qz_det[1:],[]
    #     return render_template('admin_Quiz.html', qz_data=rows,qn_data=qn_list,new_quizid=newid,new_qn_num=new_qn_num,new_qz_det=nqd)

    # if flag==1:
    #     cols=['QnNo','Question','OptionA','OptionB','OptionC','OptionD','Answer','Points']
    #     df_qn=pd.DataFrame(qn_list,columns=cols)
    #     filename=rows[-1][0]+'_'+'question.json'
    #     rel_path='/data/questions/'+filename
    #     path=os.getcwd()+rel_path      
    #     df_qn.to_json(path=path,orient='records')
    #     lists=qn_list
    #     flag,qn_list=0,[]
    #     return render_template('admin_Quiz.html', qz_data=rows,qn_data=lists,new_quizid=newid)#,new_qn_num=new_qn_num,new_qz_det=new_qz_det)
    
    return render_template('admin_Quiz.html', qz_data=rows,qn_data=qn_view,new_quizid=newid)

@app.route('/adm_quiz', methods=['POST','GET'])
def adm_add_quiz():
    if request.method=='POST':
        createdat = datetime.now().date()
        openby = datetime.strptime(request.form['openby'], '%Y-%m-%d').date()
        if (openby-createdat).days !=0:
            status='Not Opened Yet'
        else:
            status='Active'

        rel_path="/data/quiz.csv"
        path=os.getcwd()+rel_path 
        with open(path,"r") as f:
            data=f.readlines()
        rows=[]
        for line in data:
            rows.append(line.strip('\n').split(','))

        for row in rows:
            if row[0]==request.form['quizid']:
                df_quiz=pd.read_csv(path)
                df_quiz=df_quiz.astype(str)
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'QuizName'] = request.form['quizname']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Duration'] = request.form['duration']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Total'] = request.form['total']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'CreatedAt'] = str(createdat)
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'OpenBy'] = request.form['openby']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'CloseBy'] = request.form['closeby']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Status'] =status
                df_quiz.to_csv(path,index=False)
                return adm_quiz_but()


        line = request.form['quizid'] + ',' + request.form['quizname']+ ',' + request.form['duration'] + ',' + request.form['total'] + ',' + str(createdat) +','+request.form['openby'] + ',' + request.form['closeby'] + ',' + status
 
        
        with open(path,"a") as f:
            f.write(line)
            f.write("\n")
        
        qn_list=[]
        raw_list=request.form['textlist'][:-2].split(',-,')
        for each_qn in raw_list:
            qn_list.append(each_qn.split(','))
        print(request.form['textlist'])
        print(qn_list)
        cols=['QnNo','Question','OptionA','OptionB','OptionC','OptionD','Answer','Points']
        df_qn=pd.DataFrame(qn_list,columns=cols)
        filename=request.form['quizid']+'_'+'question.json'
        qn_rel_path='/data/questions/'+filename
        qn_path=os.getcwd()+qn_rel_path      
        df_qn.to_json(qn_path,orient='records')

        return adm_quiz_but()



@app.route('/adm_qz_del', methods=['POST','GET'])
def adm_qz_del_but():
    if request.method=='POST':
        qz_rel_path="/data/quiz.csv"
        qz_path=os.getcwd()+qz_rel_path
        df_quiz=pd.read_csv(qz_path)
        df_quiz=df_quiz.astype(str)
        df_quiz=df_quiz[df_quiz['QuizID'] != request.form['quizid']]
        df_quiz.to_csv(qz_path,index=False)

        directory = os.getcwd()+'/data/questions/'
        for filename in os.listdir(directory):
            if filename.split('_')[0]==request.form['quizid']:
                os.remove(directory+filename)

        return redirect('/adm_quiz')


@app.route('/adm_qn_view', methods=['POST','GET'])
def adm_qz_view_qn():
    if request.method=='POST':
        rel_path="/data/employees.csv"
        path=os.getcwd()+rel_path
        df_emp=pd.read_csv(path)
        df_emp=df_emp.astype(str)
        df_emp=df_emp[df_emp['Category'] == request.form['catid']]
        df_emp=df_emp.values.tolist()
        # df_cat.to_csv(path,index=False)
        return adm_quiz_but(df_emp)

# def adm_report_cat
# def adm_report_view



# @app.route('/adm_qn_view', methods=['POST','GET'])
# def adm_qz_view_qn():
#     if request.method=='POST':
#         rel_path="/data/questions"
#         path=os.getcwd()+rel_path
#         df_emp=pd.read_csv(path)
#         df_emp=df_emp.astype(str)
#         df_emp=df_emp[df_emp['Category'] == request.form['catid']]
#         df_emp=df_emp.values.tolist()
#         # df_cat.to_csv(path,index=False)
#         return adm_cat_but(df_emp)



# @app.route('/adm_save_quiz', methods=['POST','GET'])
# def adm_save_quiz(qn_list=[],last_qn=[],flag=0):
#     if request.method=='POST':
#         if flag==1:
#             qn_list.append(last_qn)
#             f=flag
#             rows=qn_list
#             flag,qn_list=0,[]
#             return adm_quiz_but(qn_list=rows,flag=f,new_qn_num=new_qn_No)
        
#         single_qn_list = [ request.form['questionNO'] , request.form['question'], request.form['optiona'] , request.form['optionb'] , request.form['optionc'],request.form['optiond'],request.form['options'],request.form['points']]
#         qn_list.append(single_qn_list)
#         new_qn_No=len(qn_list)+1
#         return adm_quiz_but(flag=flag,new_qn_num=new_qn_No)


# def adm_pub_quiz():
#     if request.method=='POST':
#         flag=1
#         last_qn=[ request.form['questionNO'] , request.form['question'], request.form['optiona'] , request.form['optionb'] , request.form['optionc'],request.form['optiond'],request.form['options'],request.form['points']]
#         return adm_save_quiz(flag=flag,last_qn=last_qn)















    #   <!-- QuizID,QuizName,Duration,Total,Created_By,Created_At,Open_By,Close_By,Status -->



if __name__ =='__main__':
    app.run(debug=True)