from flask import Flask,render_template,request,redirect,url_for
import os
import pandas as pd
from datetime import datetime
app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/Add_LP')
def Lp_add_home():
    return render_template('Add_LP.html')

@app.route('/Edit_LP')
def Lp_edit_home():
	rel_path="/data/learnpgm.csv"
	path=os.getcwd()+rel_path
	with open(path,"r") as f:
		data=f.readlines()
	rows=[]
	for line in data:
		rows.append(line.strip('\n').split(','))
	return render_template('Edit_LP.html',data=rows)

@app.route('/Add_LP',methods=['POST','GET'])
def add_LP():
	if request.method=='POST':
		rel_path="/data/learnpgm.csv"
		path=os.getcwd()+rel_path
		line = request.form['topic'] + ',' + request.form['dot']+ ',' + request.form['venue'] + ',' + request.form['trainer'] + ',' + request.form['status']
		with open(path,"a") as f:
			f.write(line)
			f.write("\n")
		print(line)
		return redirect('/Add_LP')

@app.route('/Edit_LP',methods=['POST','GET'])
def edit_LP():
	if request.method=='POST':
		rel_path="/data/learnpgm.csv"
		path=os.getcwd()+rel_path
		with open(path,"r") as f:
			data=f.readlines()
		rows=[]
		for line in data:
			rows.append(line.strip('\n').split(','))

		for row in rows:
			if row[0]==request.form['topic']:
				df_lp=pd.read_csv(path)
				df_lp=df_lp.astype(str)
				df_lp.loc[df_lp['Topic'] == request.form['topic'], 'Date'] = request.form['dot']
				df_lp.loc[df_lp['Topic'] == request.form['topic'], 'Venue'] = request.form['venue']
				df_lp.loc[df_lp['Topic'] == request.form['topic'], 'Trainer'] = request.form['trainer']
				df_lp.loc[df_lp['Topic'] == request.form['topic'], 'Status'] = request.form['status']
				df_lp.to_csv(path,index=False)
				return redirect('/Edit_LP')
            
               
		return redirect('/Edit_LP')

		
if __name__ =='__main__':
	app.run(debug=True)