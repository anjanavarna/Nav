from flask import Flask,render_template,request,redirect,url_for
import os
import pandas as pd
from datetime import datetime
app=Flask(__name__)

@app.route('/')
def home():
    return render_template('basic_elements.html')
                
@app.route('/adm_quiz', methods=['POST','GET'])
def adm_add_quiz():
    if request.method=='POST':
        createdat = datetime.now().date()
        openby = datetime.strptime(request.form['openby'], '%Y-%m-%d').date()
        if (openby-createdat).days !=0:
            status='Not Opened Yet'
        else:
            status='Active'

        rel_path="/data/quiz.csv"
        path=os.getcwd()+rel_path 
        with open(path,"r") as f:
            data=f.readlines()
        rows=[]
        for line in data:
            rows.append(line.strip('\n').split(','))

        for row in rows:
            if row[0]==request.form['quizid']:
                df_quiz=pd.read_csv(path)
                df_quiz=df_quiz.astype(str)
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'QuizName'] = request.form['quizname']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Duration'] = request.form['duration']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Total'] = request.form['total']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'CreatedAt'] = str(createdat)
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'OpenBy'] = request.form['openby']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'CloseBy'] = request.form['closeby']
                df_quiz.loc[df_quiz['QuizID'] == request.form['quizid'], 'Status'] =status
                df_quiz.to_csv(path,index=False)
                return adm_quiz_but()


        line = request.form['quizid'] + ',' + request.form['quizname']+ ',' + request.form['duration'] + ',' + request.form['total'] + ',' + str(createdat) +','+request.form['openby'] + ',' + request.form['closeby'] + ',' + status
 
        
        with open(path,"a") as f:
            f.write(line)
            f.write("\n")
        
        qn_list=[]
        raw_list=request.form['textlist'][:-2].split(',-,')
        for each_qn in raw_list:
            qn_list.append(each_qn.split(','))
        print(request.form['textlist'])
        print(qn_list)
        cols=['QnNo','Question','OptionA','OptionB','OptionC','OptionD','Answer','Points']
        df_qn=pd.DataFrame(qn_list,columns=cols)
        filename=request.form['quizid']+'_'+'question.json'
        qn_rel_path='/data/questions/'+filename
        qn_path=os.getcwd()+qn_rel_path      
        df_qn.to_json(qn_path,orient='records')

        return adm_quiz_but()




if __name__ =='__main__':
	app.run(debug=True)
